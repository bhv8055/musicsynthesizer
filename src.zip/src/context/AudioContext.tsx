
import React, { createContext, useState, useContext, useEffect } from 'react';

type InstrumentType = 'piano' | 'flute' | 'saxophone' | 'guitar' | 'drums';

interface AudioContextType {
  audioContext: AudioContext | null;
  currentInstrument: InstrumentType;
  setCurrentInstrument: (instrument: InstrumentType) => void;
  isRecording: boolean;
  startRecording: () => void;
  stopRecording: () => void;
  audioBlob: Blob | null;
  playNote: (note: string) => void;
  stopNote: (note: string) => void;
  playGuitar: (string: number) => void;
  playDrum: (drumType: string) => void;
  masterVolume: number;
  setMasterVolume: (volume: number) => void;
}

const AudioContextProvider = createContext<AudioContextType | undefined>(undefined);

export function useAudioContext() {
  const context = useContext(AudioContextProvider);
  if (context === undefined) {
    throw new Error('useAudioContext must be used within an AudioProvider');
  }
  return context;
}

export const AudioProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [currentInstrument, setCurrentInstrument] = useState<InstrumentType>('piano');
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [masterVolume, setMasterVolume] = useState(0.7);
  
  // Active oscillator nodes for each note
  const activeOscillators = React.useRef<Record<string, OscillatorNode>>({});
  
  useEffect(() => {
    // Initialize audio context on component mount
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    setAudioContext(ctx);
    
    return () => {
      // Clean up audio context on unmount
      if (ctx && ctx.state !== 'closed') {
        ctx.close();
      }
    };
  }, []);
  
  const startRecording = () => {
    if (!audioContext) return;
    
    // Create a media stream destination
    const destination = audioContext.createMediaStreamDestination();
    
    // Connect audio context to the destination
    const gainNode = audioContext.createGain();
    gainNode.gain.value = masterVolume;
    gainNode.connect(audioContext.destination);
    gainNode.connect(destination);
    
    // Create media recorder
    const recorder = new MediaRecorder(destination.stream);
    setMediaRecorder(recorder);
    
    const audioChunks: BlobPart[] = [];
    recorder.ondataavailable = (e) => {
      audioChunks.push(e.data);
    };
    
    recorder.onstop = () => {
      const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
      setAudioBlob(audioBlob);
    };
    
    // Start recording
    recorder.start();
    setIsRecording(true);
  };
  
  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
    }
  };

  // Helper function to get frequency for a note
  const getNoteFrequency = (note: string): number => {
    const noteToFreq: Record<string, number> = {
      'C3': 130.81, 'C#3': 138.59, 'D3': 146.83, 'D#3': 155.56,
      'E3': 164.81, 'F3': 174.61, 'F#3': 185.00, 'G3': 196.00,
      'G#3': 207.65, 'A3': 220.00, 'A#3': 233.08, 'B3': 246.94,
      'C4': 261.63, 'C#4': 277.18, 'D4': 293.66, 'D#4': 311.13,
      'E4': 329.63, 'F4': 349.23, 'F#4': 369.99, 'G4': 392.00,
      'G#4': 415.30, 'A4': 440.00, 'A#4': 466.16, 'B4': 493.88,
      'C5': 523.25, 'C#5': 554.37, 'D5': 587.33, 'D#5': 622.25,
      'E5': 659.25, 'F5': 698.46, 'F#5': 739.99, 'G5': 783.99,
      'G#5': 830.61, 'A5': 880.00, 'A#5': 932.33, 'B5': 987.77,
    };
    return noteToFreq[note] || 440;
  };
  
  // Play a note with the current instrument
  const playNote = (note: string) => {
    if (!audioContext) return;
    
    // Stop the note if it's already playing
    stopNote(note);
    
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    // Set instrument-specific settings
    switch (currentInstrument) {
      case 'piano':
        oscillator.type = 'triangle';
        break;
      case 'flute':
        oscillator.type = 'sine';
        break;
      case 'saxophone':
        oscillator.type = 'sawtooth';
        break;
      default:
        oscillator.type = 'triangle';
    }
    
    // Set frequency based on note
    oscillator.frequency.value = getNoteFrequency(note);
    
    // Apply envelope for each instrument
    if (currentInstrument === 'flute') {
      gainNode.gain.setValueAtTime(0, audioContext.currentTime);
      gainNode.gain.linearRampToValueAtTime(masterVolume * 0.8, audioContext.currentTime + 0.1);
    } else if (currentInstrument === 'saxophone') {
      gainNode.gain.setValueAtTime(0, audioContext.currentTime);
      gainNode.gain.linearRampToValueAtTime(masterVolume, audioContext.currentTime + 0.05);
      gainNode.gain.linearRampToValueAtTime(masterVolume * 0.7, audioContext.currentTime + 0.2);
    } else {
      gainNode.gain.value = masterVolume;
    }
    
    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    // Start oscillator
    oscillator.start();
    activeOscillators.current[note] = oscillator;
  };
  
  // Stop a playing note
  const stopNote = (note: string) => {
    if (!audioContext) return;
    
    const oscillator = activeOscillators.current[note];
    if (oscillator) {
      setTimeout(() => {
        oscillator.stop();
        delete activeOscillators.current[note];
      }, 50); // Small delay for better release
    }
  };
  
  // Play guitar string
  const playGuitar = (string: number) => {
    if (!audioContext) return;
    
    const baseFrequencies = [82.41, 110.00, 146.83, 196.00, 246.94, 329.63]; // E2, A2, D3, G3, B3, E4
    const frequency = baseFrequencies[string] || 110;
    
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.type = 'triangle';
    oscillator.frequency.value = frequency;
    
    // Guitar envelope
    gainNode.gain.setValueAtTime(masterVolume, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 2);
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.start();
    oscillator.stop(audioContext.currentTime + 2);
  };
  
  // Play drum sound
  const playDrum = (drumType: string) => {
    if (!audioContext) return;
    
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    switch (drumType) {
      case 'kick':
        oscillator.frequency.setValueAtTime(150, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        gainNode.gain.setValueAtTime(masterVolume, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        break;
        
      case 'snare':
        oscillator.type = 'triangle';
        oscillator.frequency.setValueAtTime(250, audioContext.currentTime);
        gainNode.gain.setValueAtTime(masterVolume * 0.7, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
        break;
        
      case 'hihat':
        oscillator.type = 'square';
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        gainNode.gain.setValueAtTime(masterVolume * 0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        break;
        
      case 'tom':
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(100, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(45, audioContext.currentTime + 0.5);
        gainNode.gain.setValueAtTime(masterVolume * 0.8, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        break;
        
      default:
        oscillator.frequency.value = 440;
        gainNode.gain.value = masterVolume * 0.5;
    }
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.start();
    oscillator.stop(audioContext.currentTime + 0.5);
  };
  
  return (
    <AudioContextProvider.Provider value={{
      audioContext,
      currentInstrument,
      setCurrentInstrument,
      isRecording,
      startRecording,
      stopRecording,
      audioBlob,
      playNote,
      stopNote,
      playGuitar,
      playDrum,
      masterVolume,
      setMasterVolume
    }}>
      {children}
    </AudioContextProvider.Provider>
  );
};

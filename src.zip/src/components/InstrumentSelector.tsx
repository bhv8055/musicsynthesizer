
import React from 'react';
import { useAudioContext } from '@/context/AudioContext';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Piano, Guitar, Drum } from 'lucide-react';

const InstrumentSelector: React.FC = () => {
  const { currentInstrument, setCurrentInstrument } = useAudioContext();

  return (
    <div className="mb-6">
      <h2 className="text-lg font-medium mb-2 text-white/80">Select Instrument</h2>
      
      <Select 
        value={currentInstrument} 
        onValueChange={(value) => setCurrentInstrument(value as any)}
      >
        <SelectTrigger className="w-full sm:w-[200px] bg-synth-dark border-synth-purple/30">
          <SelectValue placeholder="Select an instrument" />
        </SelectTrigger>
        <SelectContent className="bg-synth-dark border-synth-purple/30 text-white">
          <SelectItem value="piano" className="flex items-center">
            <div className="flex items-center">
              <Piano className="mr-2 h-4 w-4" />
              <span>Piano</span>
            </div>
          </SelectItem>
          <SelectItem value="guitar" className="flex items-center">
            <div className="flex items-center">
              <Guitar className="mr-2 h-4 w-4" />
              <span>Guitar</span>
            </div>
          </SelectItem>
          <SelectItem value="drums" className="flex items-center">
            <div className="flex items-center">
              <Drum className="mr-2 h-4 w-4" />
              <span>Drums</span>
            </div>
          </SelectItem>
        </SelectContent>
      </Select>
      
      <div className="mt-3 text-sm text-white/50">
        {currentInstrument === 'piano' && "Piano mode: Play with different instrument sounds"}
        {currentInstrument === 'drums' && "Drum mode: Percussion sounds"}
        {currentInstrument === 'guitar' && "Guitar mode: Pluck strings with your mouse or keyboard"}
      </div>
    </div>
  );
};

export default InstrumentSelector;


import React, { useState } from 'react';
import { useAudioContext } from '@/context/AudioContext';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Mic, Play, Pause, Volume2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const AudioRecorder: React.FC = () => {
  const { 
    isRecording, 
    startRecording, 
    stopRecording, 
    audioBlob,
    masterVolume, 
    setMasterVolume
  } = useAudioContext();
  
  const { toast } = useToast();
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);
  
  // Handle recording button click
  const handleRecordClick = () => {
    if (isRecording) {
      stopRecording();
      toast({
        title: "Recording stopped",
        description: "Your music has been recorded successfully!",
      });
    } else {
      startRecording();
      toast({
        title: "Recording started",
        description: "Play some notes to record your music!",
      });
    }
  };
  
  // Handle playback
  const togglePlayback = () => {
    if (!audioBlob) return;
    
    if (!audioUrl) {
      const url = URL.createObjectURL(audioBlob);
      setAudioUrl(url);
      
      const audio = new Audio(url);
      audio.onended = () => setIsPlaying(false);
      audio.play();
      setAudioElement(audio);
      setIsPlaying(true);
    } else {
      if (audioElement) {
        if (isPlaying) {
          audioElement.pause();
          setIsPlaying(false);
        } else {
          audioElement.play();
          setIsPlaying(true);
        }
      }
    }
  };
  
  // Handle volume change
  const handleVolumeChange = (value: number[]) => {
    setMasterVolume(value[0] / 100);
  };
  
  // Download recorded audio
  const downloadRecording = () => {
    if (!audioBlob) return;
    
    const url = URL.createObjectURL(audioBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sonic-orchestra-recording.wav';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="my-8 bg-synth-dark/80 rounded-lg p-6 shadow-lg">
      <h3 className="text-lg font-medium mb-4 text-white/80">Recording Studio</h3>
      
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Button 
            variant={isRecording ? "destructive" : "default"}
            className={`${isRecording ? 'animate-pulse-light' : ''}`}
            onClick={handleRecordClick}
          >
            <Mic className="mr-2 h-4 w-4" />
            {isRecording ? 'Stop Recording' : 'Start Recording'}
          </Button>
          
          <Button
            variant="outline"
            disabled={!audioBlob}
            onClick={togglePlayback}
          >
            {isPlaying ? (
              <>
                <Pause className="mr-2 h-4 w-4" />
                Pause
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Play
              </>
            )}
          </Button>
          
          {audioBlob && (
            <Button 
              variant="secondary"
              onClick={downloadRecording}
            >
              Download
            </Button>
          )}
        </div>
        
        <div className="flex items-center gap-2 w-full sm:w-auto sm:max-w-[200px]">
          <Volume2 className="h-4 w-4 text-white/70" />
          <Slider 
            className="w-32"
            defaultValue={[masterVolume * 100]} 
            max={100} 
            step={1}
            onValueChange={handleVolumeChange}
          />
          <span className="text-sm text-white/70 w-8">{Math.round(masterVolume * 100)}%</span>
        </div>
      </div>
      
      {audioBlob ? (
        <div className="mt-4 text-sm text-white/60">
          Recording available - {Math.round(audioBlob.size / 1024)} KB
        </div>
      ) : (
        <div className="mt-4 text-sm text-white/60">
          No recordings yet. Play some music and hit record!
        </div>
      )}
    </div>
  );
};

export default AudioRecorder;


import React, { useState, useEffect } from 'react';
import { useAudioContext } from '@/context/AudioContext';
import { Guitar as GuitarIcon } from 'lucide-react';

const Guitar: React.FC = () => {
  const { playGuitar } = useAudioContext();
  const [activeStrings, setActiveStrings] = useState<Record<number, boolean>>({});
  
  // Guitar has 6 strings
  const guitarStrings = [0, 1, 2, 3, 4, 5]; // E, A, D, G, B, E
  const stringNames = ['E', 'A', 'D', 'G', 'B', 'E'];
  
  // Keyboard mapping for guitar strings
  const keyMapping: Record<string, number> = {
    'z': 0, // Low E
    'x': 1, // A
    'c': 2, // D
    'v': 3, // G
    'b': 4, // B
    'n': 5, // High E
    'm': 0, // Alternative for Low E
  };
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      
      if (keyMapping[key] !== undefined) {
        handleStringPlay(keyMapping[key]);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);
  
  const handleStringPlay = (stringIndex: number) => {
    playGuitar(stringIndex);
    
    // Visual feedback for string pluck
    setActiveStrings(prev => ({ ...prev, [stringIndex]: true }));
    setTimeout(() => {
      setActiveStrings(prev => ({ ...prev, [stringIndex]: false }));
    }, 500);
  };

  return (
    <div className="my-8">
      <h3 className="text-lg font-medium mb-3 flex items-center text-white/80">
        <GuitarIcon className="mr-2 h-5 w-5" />
        Guitar
      </h3>
      
      <div className="bg-synth-dark p-6 rounded-lg shadow-lg">
        <div className="w-full max-w-3xl mx-auto">
          {guitarStrings.map((stringIndex) => (
            <div
              key={stringIndex}
              className={`guitar-string ${activeStrings[stringIndex] ? 'active' : ''}`}
              onClick={() => handleStringPlay(stringIndex)}
            >
              <span className="absolute -left-6 top-1/2 -translate-y-1/2 text-xs text-white/70">
                {stringNames[stringIndex]}
              </span>
              <span className="absolute -right-6 top-1/2 -translate-y-1/2 text-xs text-white/70">
                {Object.keys(keyMapping).find(key => keyMapping[key] === stringIndex)?.toUpperCase()}
              </span>
            </div>
          ))}
        </div>
        
        <div className="text-center text-sm mt-4 text-white/60">
          Click on strings or use keyboard keys (Z, X, C, V, B, N, M) to play
        </div>
      </div>
    </div>
  );
};

export default Guitar;

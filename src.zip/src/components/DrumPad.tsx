
import React, { useState, useEffect } from 'react';
import { useAudioContext } from '@/context/AudioContext';
import { Drum } from 'lucide-react';

const DrumPad: React.FC = () => {
  const { playDrum } = useAudioContext();
  const [activePads, setActivePads] = useState<Record<string, boolean>>({});
  
  const drums = [
    { id: 'kick', label: 'Kick', key: 'z', color: 'bg-synth-purple' },
    { id: 'snare', label: 'Snare', key: 'x', color: 'bg-synth-blue' },
    { id: 'hihat', label: 'Hi-Hat', key: 'c', color: 'bg-synth-orange' },
    { id: 'tom', label: 'Tom', key: 'v', color: 'bg-green-500' }
  ];
  
  // Keyboard controls
  useEffect(() => {
    const keyMap: Record<string, string> = {
      'z': 'kick',
      'x': 'snare',
      'c': 'hihat',
      'v': 'tom'
    };
    
    const handleKeyDown = (event: KeyboardEvent) => {
      const drumId = keyMap[event.key.toLowerCase()];
      if (drumId) {
        playDrumWithFeedback(drumId);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [playDrum]);
  
  const playDrumWithFeedback = (drumId: string) => {
    playDrum(drumId);
    
    // Visual feedback
    setActivePads(prev => ({ ...prev, [drumId]: true }));
    setTimeout(() => {
      setActivePads(prev => ({ ...prev, [drumId]: false }));
    }, 200);
  };

  return (
    <div className="my-8">
      <h3 className="text-lg font-medium mb-3 flex items-center text-white/80">
        <Drum className="mr-2 h-5 w-5" />
        Drum Pad
      </h3>
      
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {drums.map((drum) => (
          <div
            key={drum.id}
            className={`drum-pad ${activePads[drum.id] ? 'active' : ''}`}
            onClick={() => playDrumWithFeedback(drum.id)}
          >
            <div className="text-lg font-medium">{drum.label}</div>
            <div className="text-xs opacity-60 mt-1">Press '{drum.key}'</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DrumPad;

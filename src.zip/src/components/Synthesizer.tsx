
import React from 'react';
import { AudioProvider, useAudioContext } from '@/context/AudioContext';
import InstrumentSelector from './InstrumentSelector';
import PianoKeyboard from './PianoKeyboard';
import Guitar from './Guitar';
import DrumPad from './DrumPad';
import AudioRecorder from './AudioRecorder';
import { Card, CardContent } from '@/components/ui/card';
import { Music, Piano as PianoIcon } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// Instrument display component that conditionally renders based on selected instrument
const InstrumentDisplay = () => {
  const { currentInstrument, setCurrentInstrument } = useAudioContext();
  
  // Handler for keyboard instrument selection
  const handleKeyboardInstrumentSelect = (instrumentType: 'piano' | 'flute' | 'saxophone') => {
    setCurrentInstrument(instrumentType);
  };
  
  return (
    <>
      {currentInstrument === 'piano' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-white/80">Piano</h3>
            <DropdownMenu>
              <DropdownMenuTrigger className="bg-synth-dark border border-synth-purple/30 text-white px-3 py-1 rounded-md text-sm flex items-center hover:bg-synth-purple/20">
                <PianoIcon className="h-4 w-4 mr-2" />
                Keyboard Sound
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-synth-dark border-synth-purple/30 text-white">
                <DropdownMenuItem 
                  className="focus:bg-synth-purple/20 cursor-pointer" 
                  onClick={() => handleKeyboardInstrumentSelect('piano')}
                >
                  Piano
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="focus:bg-synth-purple/20 cursor-pointer" 
                  onClick={() => handleKeyboardInstrumentSelect('flute')}
                >
                  Flute
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="focus:bg-synth-purple/20 cursor-pointer"
                  onClick={() => handleKeyboardInstrumentSelect('saxophone')}
                >
                  Saxophone
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <PianoKeyboard />
        </div>
      )}
      {currentInstrument === 'guitar' && <Guitar />}
      {currentInstrument === 'drums' && <DrumPad />}
      {(currentInstrument === 'flute' || currentInstrument === 'saxophone') && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-white/80">
              {currentInstrument === 'flute' ? "Flute" : "Saxophone"}
            </h3>
            <DropdownMenu>
              <DropdownMenuTrigger className="bg-synth-dark border border-synth-purple/30 text-white px-3 py-1 rounded-md text-sm flex items-center hover:bg-synth-purple/20">
                <Music className="h-4 w-4 mr-2" />
                Keyboard Sound
              </DropdownMenuTrigger>
              <DropdownMenuContent className="bg-synth-dark border-synth-purple/30 text-white">
                <DropdownMenuItem 
                  className="focus:bg-synth-purple/20 cursor-pointer" 
                  onClick={() => handleKeyboardInstrumentSelect('piano')}
                >
                  Piano
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="focus:bg-synth-purple/20 cursor-pointer" 
                  onClick={() => handleKeyboardInstrumentSelect('flute')}
                >
                  Flute
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="focus:bg-synth-purple/20 cursor-pointer"
                  onClick={() => handleKeyboardInstrumentSelect('saxophone')}
                >
                  Saxophone
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <PianoKeyboard />
        </div>
      )}
    </>
  );
};

const Synthesizer: React.FC = () => {
  return (
    <AudioProvider>
      <Card className="bg-synth-dark border-synth-purple/30 shadow-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold flex items-center text-white">
              <Music className="mr-2 h-6 w-6 text-synth-purple" />
              <span className="bg-gradient-to-r from-synth-purple to-synth-blue bg-clip-text text-transparent">
                Sonic Orchestra Studio
              </span>
            </h2>
          </div>
          
          <InstrumentSelector />
          
          <InstrumentDisplay />
          
          <AudioRecorder />
        </CardContent>
      </Card>
    </AudioProvider>
  );
};

export default Synthesizer;


import React, { useState, useEffect } from 'react';
import { useAudioContext } from '@/context/AudioContext';

const PianoKeyboard: React.FC = () => {
  const { playNote, stopNote } = useAudioContext();
  const [activeKeys, setActiveKeys] = useState<Record<string, boolean>>({});

  // Define piano keys with their notes and types (white or black)
  const pianoKeys = [
    { note: 'C4', type: 'white' },
    { note: 'C#4', type: 'black' },
    { note: 'D4', type: 'white' },
    { note: 'D#4', type: 'black' },
    { note: 'E4', type: 'white' },
    { note: 'F4', type: 'white' },
    { note: 'F#4', type: 'black' },
    { note: 'G4', type: 'white' },
    { note: 'G#4', type: 'black' },
    { note: 'A4', type: 'white' },
    { note: 'A#4', type: 'black' },
    { note: 'B4', type: 'white' },
    { note: 'C5', type: 'white' },
    { note: 'C#5', type: 'black' },
    { note: 'D5', type: 'white' },
    { note: 'D#5', type: 'black' },
    { note: 'E5', type: 'white' }
  ];

  // Keyboard mapping for piano keys
  const keyboardMap: Record<string, string> = {
    'a': 'C4',
    'w': 'C#4',
    's': 'D4',
    'e': 'D#4',
    'd': 'E4',
    'f': 'F4',
    't': 'F#4',
    'g': 'G4',
    'y': 'G#4',
    'h': 'A4',
    'u': 'A#4',
    'j': 'B4',
    'k': 'C5',
    'o': 'C#5',
    'l': 'D5',
    'p': 'D#5',
    ';': 'E5'
  };

  // Handle keyboard events
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      const note = keyboardMap[event.key.toLowerCase()];
      if (note && !activeKeys[note]) {
        setActiveKeys(prev => ({ ...prev, [note]: true }));
        playNote(note);
      }
    };

    const handleKeyUp = (event: KeyboardEvent) => {
      const note = keyboardMap[event.key.toLowerCase()];
      if (note) {
        setActiveKeys(prev => ({ ...prev, [note]: false }));
        stopNote(note);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [playNote, stopNote, activeKeys, keyboardMap]);

  // Handle touch/mouse events
  const handleMouseDown = (note: string) => {
    setActiveKeys(prev => ({ ...prev, [note]: true }));
    playNote(note);
  };

  const handleMouseUp = (note: string) => {
    setActiveKeys(prev => ({ ...prev, [note]: false }));
    stopNote(note);
  };

  const handleTouchStart = (note: string, event: React.TouchEvent) => {
    event.preventDefault(); // Prevent scrolling while playing
    setActiveKeys(prev => ({ ...prev, [note]: true }));
    playNote(note);
  };

  const handleTouchEnd = (note: string, event: React.TouchEvent) => {
    event.preventDefault();
    setActiveKeys(prev => ({ ...prev, [note]: false }));
    stopNote(note);
  };

  // Calculate position for black keys
  const getBlackKeyPosition = (index: number) => {
    // Find the position of this black key's white key predecessor
    const whiteKeyIndex = pianoKeys.slice(0, index).filter(k => k.type === 'white').length;
    
    // Return position (each white key is 3.5rem wide)
    return `${(whiteKeyIndex * 3.5) - 0.8}rem`;
  };

  return (
    <div className="relative mb-8 overflow-x-auto">
      <div className="flex justify-center h-48 relative">
        {/* White keys - render first to be behind black keys */}
        {pianoKeys.filter(key => key.type === 'white').map((key, index) => (
          <div
            key={key.note}
            className={`piano-key white ${activeKeys[key.note] ? 'active' : ''}`}
            onMouseDown={() => handleMouseDown(key.note)}
            onMouseUp={() => handleMouseUp(key.note)}
            onMouseOut={() => activeKeys[key.note] && handleMouseUp(key.note)}
            onTouchStart={(e) => handleTouchStart(key.note, e)}
            onTouchEnd={(e) => handleTouchEnd(key.note, e)}
          >
            <span className="absolute bottom-2 left-0 right-0 text-center text-xs opacity-70">
              {key.note.replace(/[0-9]/g, '')}
              <span className="block opacity-50 text-[10px]">
                {Object.keys(keyboardMap).find(k => keyboardMap[k] === key.note)}
              </span>
            </span>
          </div>
        ))}
        
        {/* Black keys - render on top */}
        {pianoKeys.filter(key => key.type === 'black').map((key, blackKeyIndex) => {
          // Find the index in the original array
          const originalIndex = pianoKeys.findIndex(k => k.note === key.note);
          
          return (
            <div
              key={key.note}
              className={`piano-key black ${activeKeys[key.note] ? 'active' : ''}`}
              style={{
                left: getBlackKeyPosition(originalIndex)
              }}
              onMouseDown={() => handleMouseDown(key.note)}
              onMouseUp={() => handleMouseUp(key.note)}
              onMouseOut={() => activeKeys[key.note] && handleMouseUp(key.note)}
              onTouchStart={(e) => handleTouchStart(key.note, e)}
              onTouchEnd={(e) => handleTouchEnd(key.note, e)}
            >
              <span className="absolute bottom-2 left-0 right-0 text-center text-xs opacity-70">
                {key.note.replace(/[0-9]/g, '')}
                <span className="block opacity-50 text-[10px] text-white">
                  {Object.keys(keyboardMap).find(k => keyboardMap[k] === key.note)}
                </span>
              </span>
            </div>
          );
        })}
      </div>
      <div className="text-center text-sm mt-3 text-white/60">
        Play with mouse/touch or use your computer keyboard
      </div>
    </div>
  );
};

export default PianoKeyboard;


import React from 'react';
import Synthesizer from '@/components/Synthesizer';

const Index = () => {
  return (
    <div className="min-h-screen p-4 md:p-6 bg-gradient-to-br from-synth-dark to-synth-purple/20">
      <div className="container mx-auto max-w-5xl">
        <header className="text-center mb-8">
          <h1 className="text-3xl md:text-5xl font-bold mb-2 text-white">
            <span className="bg-gradient-to-r from-synth-blue via-synth-purple to-synth-orange bg-clip-text text-transparent">
              Sonic Orchestra Studio
            </span>
          </h1>
          <p className="text-white/70 text-lg">
            A virtual music studio with multiple instruments and recording capabilities
          </p>
        </header>
        
        <main>
          <Synthesizer />
        </main>
        
        <footer className="mt-12 text-center text-sm text-white/50">
          <p>Use your mouse, touchscreen, or keyboard to play the instruments.</p>
          <p>Record your compositions and download them to share!</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
